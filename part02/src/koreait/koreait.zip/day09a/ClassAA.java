package koreait.day09a;

public class ClassAA extends ClassA {	//super(부모)  클래스는 ClassA
	
	//ClassAA 의 인스턴스 메소드
	//mane 필드 상속받은 것으로 여기서 선언하지 않습니다
	
	void test() {
		setName("나연");
		System.out.println("name = "+name);
	}
	
	
	}

