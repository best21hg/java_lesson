package koreait.day09a;
//연속적인 상속이 가능하다 ClassA ->ClassAA ->ClassAAA 부모클래스안에 변수와 메소드 사용가능
public class ClassAAA {

}
